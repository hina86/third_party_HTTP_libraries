package com.ut.berkerdemirer.asynchttp.model;

import java.util.ArrayList;

public class TimeTable {

    private String course_uuid;
    private EventType eventType = new EventType();
    private State state = new State();
    private StudyWorkType studyWorkType = new StudyWorkType();
    private ArrayList<Lecturer> lecturers = new ArrayList<>();
    private Time time = new Time();
    private Location location = new Location();

    public String getCourse_uuid() {
        return course_uuid;
    }

    public void setCourse_uuid(String course_uuid) {
        this.course_uuid = course_uuid;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public StudyWorkType getStudyWorkType() {
        return studyWorkType;
    }

    public void setStudyWorkType(StudyWorkType studyWorkType) {
        this.studyWorkType = studyWorkType;
    }

    public ArrayList<Lecturer> getLecturers() {
        return lecturers;
    }

    public void setLecturers(ArrayList<Lecturer> lecturers) {
        this.lecturers = lecturers;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "TimeTable{" +
                "course_uuid='" + course_uuid + '\'' +
                ", eventType=" + eventType +
                ", state=" + state +
                ", studyWorkType=" + studyWorkType +
                ", lecturers=" + lecturers +
                ", time=" + time +
                ", location=" + location +
                '}';
    }
}
