package com.ut.berkerdemirer.okhttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ut.berkerdemirer.okhttp.model.Lecturer;
import com.ut.berkerdemirer.okhttp.model.TimeTable;
import com.ut.berkerdemirer.okhttp.model.TimeTableWrapper;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TimeTable timeTable = new TimeTable();
    TimeTableWrapper timeTableWrapper;
    int responseCounter = 0;
    ArrayList<TimeTableWrapper> list = new ArrayList<TimeTableWrapper>();
    long listsize =0;
    private static final String OkHttp_V5_Serialize_Jackson_ACTIVITY_STARTED = "Activity Started";
    private static final String OkHttp_V5_Serialize_Jackson_ACTIVITY_ENDED = "Activity Ended";

    private static final String OkHttp_V5_Serialize_Jackson_LOOP_STARTED = "Loop Started";

    //private static final String OkHttp_V5_Serialize_Jackson_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        // Log when app is started
        Log.i(OkHttp_V5_Serialize_Jackson_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        try {
            makePostRequest();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    //@DebugLog
    private void prepareObject() {

        timeTable.setCourse_uuid("8b2d757615a37be8934e041a1715d463");

        timeTable.getEventType().setCode("lecture");
        timeTable.getEventType().setEt("õppetund");
        timeTable.getEventType().setEn("lecture");

        timeTable.getState().setCode("confirmed");
        timeTable.getState().setEt("Kinnitatud");
        timeTable.getState().setCode("confirmed");

        timeTable.getStudyWorkType().setCode("lecture");
        timeTable.getStudyWorkType().setEt("loeng");
        timeTable.getStudyWorkType().setEn("lecture");

        Lecturer lecturer = new Lecturer();
        lecturer.setPerson_uuid("1b22301eea89eda36beaad7f068e692c");
        lecturer.setAcademic_weeks("24-31");

        timeTable.getLecturers().add(lecturer);
        timeTable.getTime().setAcademic_weeks("24-31");
        timeTable.getTime().getWeekDay().setCode("2");
        timeTable.getTime().getWeekDay().setEt("Teisipäev");
        timeTable.getTime().getWeekDay().setEn("Tuesday");
        timeTable.getTime().setSince_date("2019-02-12");
        timeTable.getTime().setUntil_date("2019-04-02");
        timeTable.getTime().setBegin_time("10:15:00");
        timeTable.getTime().setEnd_time("12:00:00");

        timeTable.getLocation().setLocation_uuid("91737da5345e38fe3338c116c2e9a190");
        timeTable.getLocation().setAddress("J. Liivi 2 - 405");

        timeTableWrapper = new TimeTableWrapper(timeTable);
        for (int i=0; listsize <= 1630; i++) { //list size = 1630 gives a string of length 998173 (this is number of characters in string)  which occupies 1.00mb in memory
            list.add( timeTableWrapper );
            listsize= list.size();

        }
    }

    //@DebugLog
    public String serializeObject() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(list);
    }

    //@DebugLog
    public void makePostRequest() throws JsonProcessingException {

        prepareObject();
        String obj = serializeObject();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", "jsonObj", RequestBody.create(MediaType.parse("application/json"), obj))
                .build();

        String url = "https://desolate-beach-17272.herokuapp.com/uploadFile";
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .build();

        //start loop
        Log.i(OkHttp_V5_Serialize_Jackson_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
     //   Log.i(OkHttp_V5_Serialize_Jackson_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e("ERROR", e.getMessage());
                    finish();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    responseCounter += 1;
                   // Log.d("response", response.toString());
                    Log.d("RESPONSE COUNTER", " " + responseCounter);

                    if (responseCounter == 29) {
                        //terminate app
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        //garbage collector
      //  System.gc();

        // end the app
        Log.i(OkHttp_V5_Serialize_Jackson_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }


}
