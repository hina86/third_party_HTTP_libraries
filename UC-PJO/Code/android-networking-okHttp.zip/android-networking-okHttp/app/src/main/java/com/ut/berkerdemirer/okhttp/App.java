package com.ut.berkerdemirer.okhttp;

import android.app.Application;

import okhttp3.OkHttpClient;

public class App extends Application {

    private OkHttpClient client;
    private static App sInstance = null;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        client = new OkHttpClient();
    }

    public OkHttpClient getClient() {
        return client;
    }

    public static App getInstance() {
        return sInstance;
    }
}
