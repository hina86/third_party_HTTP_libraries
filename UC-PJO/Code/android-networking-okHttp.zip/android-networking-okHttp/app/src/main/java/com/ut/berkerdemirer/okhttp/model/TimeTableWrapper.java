package com.ut.berkerdemirer.okhttp.model;



public class TimeTableWrapper {

    public final TimeTable timeTable;

    public TimeTableWrapper(TimeTable timeTable) {
        this.timeTable = timeTable;
    }

    @Override
    public String toString() {
        return "TimeTableWrapper{" +
                "timeTable=" + timeTable +
                '}';
    }
}
