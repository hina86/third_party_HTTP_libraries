package com.ut.berkerdemirer.okhttp.model;

public class StudyWorkType {

    private String code;
    private String et;
    private String en;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEt() {
        return et;
    }

    public void setEt(String et) {
        this.et = et;
    }

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    @Override
    public String toString() {
        return "StudyWorkType{" +
                "code='" + code + '\'' +
                ", et='" + et + '\'' +
                ", en='" + en + '\'' +
                '}';
    }
}
