package com.ut.berkerdemirer.myapplication.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TimeTableWrapper {

    @JsonProperty("dailyTimeTable")
    public final TimeTable timeTable;

    public TimeTableWrapper(TimeTable timeTable) {
        this.timeTable = timeTable;
    }
}
