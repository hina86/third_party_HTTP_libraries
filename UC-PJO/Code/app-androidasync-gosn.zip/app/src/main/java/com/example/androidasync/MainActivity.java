package com.example.androidasync;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.androidasync.model.Lecturer;
import com.example.androidasync.model.TimeTable;
import com.example.androidasync.model.TimeTableWrapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpPost;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.body.MultipartFormDataBody;
import com.koushikdutta.async.http.callback.HttpConnectCallback;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TimeTable timeTable = new TimeTable();
    TimeTableWrapper timeTableWrapper;
    ArrayList<TimeTableWrapper> list = new ArrayList<TimeTableWrapper>();
    long listsize =0;
    private int responseCounter = 0;
    //String str;
    private static final String AndroidAsync_V3_SERIALIZE_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String AndroidAsync_V3_SERIALIZE_GSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String AndroidAsync_V3_SERIALIZE_GSON_LOOP_STARTED = "Loop Started";


    //private static final String AndroidAsync_V3_SERIALIZE_GSON_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AndroidAsync_V3_SERIALIZE_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        prepareObject();
        postFile();
       // serializeObject();
    }


    private void prepareObject() {

       timeTable.setCourse_uuid("8b2d757615a37be8934e041a1715d463");

        timeTable.getEventType().setCode("lecture");
        timeTable.getEventType().setEt("õppetund");
        timeTable.getEventType().setEn("lecture");

        timeTable.getState().setCode("confirmed");
        timeTable.getState().setEt("Kinnitatud");
        timeTable.getState().setCode("confirmed");

        timeTable.getStudyWorkType().setCode("lecture");
        timeTable.getStudyWorkType().setEt("loeng");
        timeTable.getStudyWorkType().setEn("lecture");

        Lecturer lecturer = new Lecturer();
        lecturer.setPerson_uuid("1b22301eea89eda36beaad7f068e692c");
        lecturer.setAcademic_weeks("24-31");

        timeTable.getLecturers().add(lecturer);
        timeTable.getTime().setAcademic_weeks("24-31");
        timeTable.getTime().getWeekDay().setCode("2");
        timeTable.getTime().getWeekDay().setEt("Teisipäev");
        timeTable.getTime().getWeekDay().setEn("Tuesday");
        timeTable.getTime().setSince_date("2019-02-12");
        timeTable.getTime().setUntil_date("2019-04-02");
        timeTable.getTime().setBegin_time("10:15:00");
        timeTable.getTime().setEnd_time("12:00:00");

        timeTable.getLocation().setLocation_uuid("91737da5345e38fe3338c116c2e9a190");
        timeTable.getLocation().setAddress("J. Liivi 2 - 405");

        timeTableWrapper = new TimeTableWrapper(timeTable);

        for (int i=0; listsize <= 1630; i++) { //list size = 1630 gives a string of length 998173 (this is number of characters in string)  which occupies 1.00mb in memory
            list.add( timeTableWrapper );
            listsize= list.size();
        }

    }


    public String serializeObject() {

        Gson gson = new Gson();
        Type listType = new TypeToken<ArrayList<TimeTableWrapper>>() {}.getType();
        String studentTimeTable = gson.toJson(list, listType);
       //String studentTimeTable = gson.toJson(timeTableWrapper);
       // Log.d("Serialized", studentTimeTable);
        return studentTimeTable;
    }

    public void postFile() {
        String url = "https://desolate-beach-17272.herokuapp.com/uploadJSON";
        String str = serializeObject();
        //Log.d("post file string", str);
        AsyncHttpPost post = new AsyncHttpPost(url);
        MultipartFormDataBody body = new MultipartFormDataBody();
        body.addStringPart("file",str);
        body.setContentType("application/json");
        post.setBody(body);
        post.setTimeout( 100000000 );

        //start loop
        Log.i(AndroidAsync_V3_SERIALIZE_GSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(AndroidAsync_V3_SERIALIZE_GSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 30; i++) {
            AsyncHttpClient.getDefaultInstance().execute(post, new HttpConnectCallback() {
                @Override
                public void onConnectCompleted(Exception ex, AsyncHttpResponse response) {
                    responseCounter++;
                    Log.d("response", String.valueOf( response.code() ) );
                    //Log.d("response", String.valueOf( responseCounter ) );
                    if(responseCounter == 30){
                        finish();
                    }
                    else if(ex != null){
                        ex.printStackTrace();
                       finish();
                    }
                }
            });
        }

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(AndroidAsync_V3_SERIALIZE_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
