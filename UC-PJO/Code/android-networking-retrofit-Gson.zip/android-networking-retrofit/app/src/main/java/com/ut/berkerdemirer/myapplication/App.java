package com.ut.berkerdemirer.myapplication;

import android.app.Application;

public class App extends Application {
    private static App sInstance = null;
    RetrofitInterface retrofitInterface;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        retrofitInterface = ServiceGenerator.createService(RetrofitInterface.class);
    }

    public RetrofitInterface getRetrofitInterface() {
        return retrofitInterface;
    }

    public static App getInstance() {
        return sInstance;
    }
}
