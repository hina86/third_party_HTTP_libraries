package com.ut.berkerdemirer.myapplication.Model;

import com.google.gson.annotations.SerializedName;

public class TimeTableWrapper {

    @SerializedName("dailyTimeTable")
    public final TimeTable timeTable;

    public TimeTableWrapper(TimeTable timeTable) {
        this.timeTable = timeTable;
    }
}
