package com.ut.berkerdemirer.asynchttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.Types;
import com.ut.berkerdemirer.asynchttp.model.Lecturer;
import com.ut.berkerdemirer.asynchttp.model.TimeTable;
import com.ut.berkerdemirer.asynchttp.model.TimeTableWrapper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    TimeTable timeTable = new TimeTable();
    TimeTableWrapper timeTableWrapper;
    List<TimeTableWrapper> list = new ArrayList<TimeTableWrapper>();
    long listsize =0;
    private int responseCounter = 0;

    private static final String AsyncHttpClient_V9_SERIALIZE_MOSHI_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V9_SERIALIZE_MOSHI_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V9_SERIALIZE_MOSHI_LOOP_STARTED = "Loop Started";

   // private static final String AsyncHttpClient_V9_SERIALIZE_MOSHI_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AsyncHttpClient_V9_SERIALIZE_MOSHI_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        prepareObject();
        postMultipartContent();
    }


    //@DebugLog
    private void prepareObject() {

        timeTable.setCourse_uuid("8b2d757615a37be8934e041a1715d463");

        timeTable.getEventType().setCode("lecture");
        timeTable.getEventType().setEt("õppetund");
        timeTable.getEventType().setEn("lecture");

        timeTable.getState().setCode("confirmed");
        timeTable.getState().setEt("Kinnitatud");
        timeTable.getState().setCode("confirmed");

        timeTable.getStudyWorkType().setCode("lecture");
        timeTable.getStudyWorkType().setEt("loeng");
        timeTable.getStudyWorkType().setEn("lecture");

        Lecturer lecturer = new Lecturer();
        lecturer.setPerson_uuid("1b22301eea89eda36beaad7f068e692c");
        lecturer.setAcademic_weeks("24-31");

        timeTable.getLecturers().add(lecturer);
        timeTable.getTime().setAcademic_weeks("24-31");
        timeTable.getTime().getWeekDay().setCode("2");
        timeTable.getTime().getWeekDay().setEt("Teisipäev");
        timeTable.getTime().getWeekDay().setEn("Tuesday");
        timeTable.getTime().setSince_date("2019-02-12");
        timeTable.getTime().setUntil_date("2019-04-02");
        timeTable.getTime().setBegin_time("10:15:00");
        timeTable.getTime().setEnd_time("12:00:00");

        timeTable.getLocation().setLocation_uuid("91737da5345e38fe3338c116c2e9a190");
        timeTable.getLocation().setAddress("J. Liivi 2 - 405");

        timeTableWrapper = new TimeTableWrapper(timeTable);
        for (int i=0; listsize <= 1630; i++) { //list size = 1630 gives a string of length 998173 (this is number of characters in string)  which occupies 1.00mb in memory
            list.add( timeTableWrapper );
            listsize= list.size();

        }
    }

    //@DebugLog
    public String serializeObject() {
        //prepareObject();
        Moshi moshi = new Moshi.Builder().build();

        //JsonAdapter<TimeTableWrapper> jsonAdapter = moshi.adapter(TimeTableWrapper.class);
        Type listMyData = Types.newParameterizedType( List.class, TimeTableWrapper.class);
        JsonAdapter<List<TimeTableWrapper>> adapter = moshi.adapter(listMyData);
        return adapter.toJson( list );
    }

    //@DebugLog
    public void postMultipartContent() {

        RequestParams params = new RequestParams();
        try {
            params.put("file", writeJsonToFile());
            params.setForceMultipartEntityContentType(true);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //start loop
        Log.i(AsyncHttpClient_V9_SERIALIZE_MOSHI_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(AsyncHttpClient_V9_SERIALIZE_MOSHI_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().post("https://desolate-beach-17272.herokuapp.com/uploadFile", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    responseCounter++;
                    Log.d("Response", "" + statusCode);

                    if (responseCounter == 29) {
                        finish();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Log.d("error", error.toString());
                    finish();
                }
            });
        }
    }

    //@DebugLog
    public File writeJsonToFile() {

        String obj = serializeObject();
        File f = new File(getCacheDir() + "/" + "timetable");
        JSONObject jsonObject;

        try {
            jsonObject = new JSONObject();
            jsonObject.put("data", obj);
           // Log.d("JSON", jsonObject + "");
            f.createNewFile();
            FileWriter writer = new FileWriter(f);
           writer.write(jsonObject.toString());
            writer.flush();
            writer.close();

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(AsyncHttpClient_V9_SERIALIZE_MOSHI_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

}
