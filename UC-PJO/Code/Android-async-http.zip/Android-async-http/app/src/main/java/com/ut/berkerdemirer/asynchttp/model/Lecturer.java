package com.ut.berkerdemirer.asynchttp.model;

public class Lecturer {

    private String person_uuid;
    private String academic_weeks;

    public String getPerson_uuid() {
        return person_uuid;
    }

    public void setPerson_uuid(String person_uuid) {
        this.person_uuid = person_uuid;
    }

    public String getAcademic_weeks() {
        return academic_weeks;
    }

    public void setAcademic_weeks(String academic_weeks) {
        this.academic_weeks = academic_weeks;
    }

    @Override
    public String toString() {
        return "Lecturer{" +
                "person_uuid='" + person_uuid + '\'' +
                ", academic_weeks='" + academic_weeks + '\'' +
                '}';
    }
}
