package com.ut.berkerdemirer.volley;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.ut.berkerdemirer.volley.model.Lecturer;
import com.ut.berkerdemirer.volley.model.TimeTable;
import com.ut.berkerdemirer.volley.model.TimeTableWrapper;

import org.json.JSONException;
import org.json.JSONObject;



import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import hugo.weaving.DebugLog;

public class MainActivity extends AppCompatActivity {


    int sizeOfCall = 100;
    TimeTable timeTable = new TimeTable();
    TimeTableWrapper timeTableWrapper;
    ArrayList<TimeTableWrapper> list = new ArrayList<TimeTableWrapper>();
    long listsize =0;
    int responseCounter = 0;
    private static final String Retrofit_V3_Serialize_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String Retrofit_V3_Serialize_GSON_ACTIVITY_ENDED = "Activity Ended";

    private String url = "https://desolate-beach-17272.herokuapp.com/uploadJSON";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Retrofit_V3_Serialize_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        try {
            prepareObject();
        } catch (IOException e) {
            e.printStackTrace();
        }
        postJson();
    }

    //@DebugLog
    //Fill in the java object for serializing
    private void prepareObject() throws IOException {

        timeTable.setCourse_uuid("8b2d757615a37be8934e041a1715d463");

        timeTable.getEventType().setCode("lecture");
        timeTable.getEventType().setEt("õppetund");
        timeTable.getEventType().setEn("lecture");

        timeTable.getState().setCode("confirmed");
        timeTable.getState().setEt("Kinnitatud");
        timeTable.getState().setCode("confirmed");

        timeTable.getStudyWorkType().setCode("lecture");
        timeTable.getStudyWorkType().setEt("loeng");
        timeTable.getStudyWorkType().setEn("lecture");

        Lecturer lecturer = new Lecturer();
        lecturer.setPerson_uuid("1b22301eea89eda36beaad7f068e692c");
        lecturer.setAcademic_weeks("24-31");

        timeTable.getLecturers().add(lecturer);
        timeTable.getTime().setAcademic_weeks("24-31");
        timeTable.getTime().getWeekDay().setCode("2");
        timeTable.getTime().getWeekDay().setEt("Teisipäev");
        timeTable.getTime().getWeekDay().setEn("Tuesday");
        timeTable.getTime().setSince_date("2019-02-12");
        timeTable.getTime().setUntil_date("2019-04-02");
        timeTable.getTime().setBegin_time("10:15:00");
        timeTable.getTime().setEnd_time("12:00:00");

        timeTable.getLocation().setLocation_uuid("91737da5345e38fe3338c116c2e9a190");
        timeTable.getLocation().setAddress("J. Liivi 2 - 405");

        timeTableWrapper = new TimeTableWrapper(timeTable);

        for (int i=0; listsize <= 1630; i++) { //list size = 1630 gives a string of length 998173 (this is number of characters in string)  which occupies 1.00mb in memory
            list.add( timeTableWrapper );
            listsize= list.size();

        }





    }



    //@DebugLog
    // serialize the object using gson library

     public JSONObject serializeObject() {




        Gson gson = new Gson();
        JSONObject obj = null;
        Type listType = new TypeToken<ArrayList<TimeTableWrapper>>() {}.getType();
        String studentTimeTable = gson.toJson(list, listType);


         //Log.d("String size", String.valueOf( studentTimeTable.length() ) );
       //  Log.d("String size byte", String.valueOf( studentTimeTable.getBytes().length ) );
        try {
            obj = new JSONObject(  );
            obj.put("data", studentTimeTable);
            //System.out.println(obj);
           // Log.d("JSONObject", String.valueOf( obj.length() ) );


        } catch (JSONException e) {

            e.printStackTrace();
           // Log.d("JSONObject error :" , String.valueOf( listsize ) );
        }
         return obj;

    }

    //@DebugLog
    // make post request
    public void postJson() {

        // create new request queue for async post
        RequestQueue queue = Volley.newRequestQueue( this );
       JSONObject obj = serializeObject();
        // Volley either makes json object request or string request. So I configured the server to accept json bodyç
        for (int i = 0; i < 30; i++) {
            JsonObjectRequest jsonObjReq = new JsonObjectRequest( Request.Method.POST, url, obj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    responseCounter++;
                    Log.d( "SUCCESS", response.toString() );
                    if (responseCounter == 29) {
                        finish();
                    }
                    // Uncomment below code to make concurrent requests
               /* sizeOfCall--;
                if (sizeOfCall > 0) {
                    postJson();
                } else {
                    finish();
                }*/
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e( "ERROR", error.toString() );
                }
            } );

            queue.add( jsonObjReq );
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(Retrofit_V3_Serialize_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }


}
