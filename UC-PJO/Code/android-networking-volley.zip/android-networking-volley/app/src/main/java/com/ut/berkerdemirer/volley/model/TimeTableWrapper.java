package com.ut.berkerdemirer.volley.model;


import com.fasterxml.jackson.annotation.JsonProperty;

public class TimeTableWrapper {

    @JsonProperty("dailyTimeTable")
    public final TimeTable timeTable;

    public TimeTableWrapper(TimeTable timeTable) {
        this.timeTable = timeTable;
    }

    @Override
    public String toString() {
        return "TimeTableWrapper{" +
                "timeTable=" + timeTable +
                '}';
    }
}
