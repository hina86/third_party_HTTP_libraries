package com.example.androidasync;

import android.os.Debug;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpPost;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.body.MultipartFormDataBody;
import com.koushikdutta.async.http.callback.HttpConnectCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {


    private int responseCounter = 0;

    private static final String AndroidAsync_V2_POST_ACTIVITY_STARTED = "Activity Started";
    private static final String AndroidAsync_V2_POST_ACTIVITY_ENDED = "Activity Ended";

    private static final String AndroidAsync_V2_POST_LOOP_STARTED = "Loop Started";

  //  private static final String AndroidAsync_V2_POST_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AndroidAsync_V2_POST_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getFile();
    }

    public void getFile() {
        String url = "https://desolate-beach-17272.herokuapp.com/uploadFile";

        AsyncHttpPost post = new AsyncHttpPost(url);

        MultipartFormDataBody body = new MultipartFormDataBody();
        body.addFilePart("file", createFileFromAssetsFolder("1mb1.jpg"));
        post.setBody(body);

        //start loop
        Log.i(AndroidAsync_V2_POST_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
       // Log.i(AndroidAsync_V2_POST_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 100; i++) {

            AsyncHttpClient.getDefaultInstance().execute(post, new HttpConnectCallback() {
                @Override
                public void onConnectCompleted(Exception ex, AsyncHttpResponse response) {
                    Log.d("success response", response + "");
                    responseCounter++;
                    if (responseCounter == 99) {
                        finish();
                    }
                }
            });

        }
       // finish();

    }

    @NonNull
    static String getMimeType(@NonNull File file) {
        String type = null;
        final String url = file.toString();
        final String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        if (type == null) {
            type = "*/*"; // fallback type.
        }
        return type;
    }

    // Use this method to create new file object from asset folder
    public File createFileFromAssetsFolder(String name) {

        File f = new File(getCacheDir() + "/" + name);
        if (!f.exists())
            try {

                InputStream is = getAssets().open(name);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();

                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        return f;
    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(AndroidAsync_V2_POST_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
