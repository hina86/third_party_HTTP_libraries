package com.ut.berkerdemirer.volley;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    int responseCounter = 0;

    private static final String Volley_V2_POST_ACTIVITY_STARTED = "Activity Started";
    private static final String Volley_V2_POST_ACTIVITY_ENDED = "Activity Ended";

    private static final String Volley_V2_POST_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V2_POST_MEMORY_BEFORE = "Memory Before";


    File f;
    String mimeType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Volley_V2_POST_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);

        // get the File object
        f = createFileFromAssetsFolder("1mb1.jpg");
        // get the content type of the file object
        mimeType = getMimeType(f);
        //make the request
        // File to be uploaded
        String url = "https://desolate-beach-17272.herokuapp.com/uploadFile";
        makeGetRequest(url);
    }

    //@DebugLog
    public void makeGetRequest(final String url) {

        //start loop
        Log.i(Volley_V2_POST_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       /// Log.i(Volley_V2_POST_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
                @Override
                public void onResponse(NetworkResponse response) {
                    responseCounter++;
                    Log.d("success", "" + response.toString());
                    if (responseCounter == 99) {
                        finish();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d("FAIL", error.toString());
                    finish();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    return null;
                }

                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    // file name could found file base or direct access from real path
                    // for now just get bitmap data from ImageView
                    try {
                        params.put("file", new DataPart(f.getName(), getFileBytes(), mimeType));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return params;
                }
            };

            //Creates a default instance of the worker pool and calls RequestQueue.start() on it.
            VolleySingleton.getInstance(this).getRequestQueue().add(multipartRequest);
        }

    }

    /*
     This method is used to determine the type of the File. Such as image/jpeg, video/mp4 etc.
     */

    //@DebugLog
    @NonNull
    static String getMimeType(@NonNull File file) {
        String type = null;
        final String url = file.toString();
        final String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        if (type == null) {
            type = "*/*"; // fallback type.
        }
        return type;
    }

    /*

    Since volley can't send a file to the server in the form of File, we need the byte[] equivalent of the file
    This method get's the content from assets folder and turns it into byte[]

    */
    //@DebugLog
    public byte[] getFileBytes() throws IOException {

        InputStream inputStream = null;
        try {
            inputStream = getAssets().open("1mb1.jpg");
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] buffer = new byte[8192];
        int bytesRead;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
        byte file[] = output.toByteArray();

        return file;
    }


    /*
     This method generates a file from assets folder and stores it in the cache dir. If the file is already generated it
     it returns the requested file.
     This method is needed to get file's mimetype dynamically.
     */

    //@DebugLog
    public File createFileFromAssetsFolder(String name) {

        File f = new File(getCacheDir() + "/" + name);
        if (!f.exists())
            try {
                InputStream is = getAssets().open(name);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();

                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        return f;
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
      //  System.gc();
        //end the app
        Log.i(Volley_V2_POST_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
