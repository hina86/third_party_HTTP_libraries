package com.ut.berkerdemirer.okhttp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String OkHttp_V4_POST_ACTIVITY_STARTED = "Activity Started";
    private static final String OkHttp_V4_POST_ACTIVITY_ENDED = "Activity Ended";

    private static final String OkHttp_V4_POST_LOOP_STARTED = "Loop Started";

   // private static final String OkHttp_V4_POST_MEMORY_BEFORE = "Memory Before";

    private int responseCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(OkHttp_V4_POST_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        makePostRequest();
    }

    //@DebugLog
    public void makePostRequest() {

        MediaType MEDIA_TYPE = null;
        File f = createFileFromAssetsFolder("1mb1.jpg");
        String url = "https://desolate-beach-17272.herokuapp.com/uploadFile";
        String fileType = getMimeType(f);
        MEDIA_TYPE = MediaType.parse(fileType);

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", f.getName(), RequestBody.create(MEDIA_TYPE, f))
                .build();
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .build();

        Log.i(OkHttp_V4_POST_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
      //  Log.i(OkHttp_V4_POST_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            App.getInstance().getClient().newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    finish();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    responseCounter += 1;
                    Log.d("success response", response.toString());
                    if (responseCounter == 99) {
                        //terminate app
                        finish();
                    }

                }
            });
        }

    }

    @NonNull
    static String getMimeType(@NonNull File file) {
        String type = null;
        final String url = file.toString();
        final String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        if (type == null) {
            type = "*/*"; // fallback type.
        }
        return type;
    }

    // Use this method to create new file object from asset folder
    public File createFileFromAssetsFolder(String name) {

        File f = new File(getCacheDir() + "/" + name);
        if (!f.exists())
            try {

                InputStream is = getAssets().open(name);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();

                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        return f;
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
      //  System.gc();
        //garbage collector
        Log.i(OkHttp_V4_POST_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
