package com.ut.berkerdemirer.myapplication;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import hugo.weaving.DebugLog;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {


    int responseCounter = 0;

    private static final String Retrofit_V2_POST_ACTIVITY_STARTED = "Activity Started";
    private static final String Retrofit_V2_POST_ACTIVITY_ENDED = "Activity Ended";

    private static final String Retrofit_V2_POST_LOOP_STARTED = "Loop Started";

   // private static final String Retrofit_V2_POST_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i(Retrofit_V2_POST_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        makePostRequest();

    }

    //@DebugLog
    private void makePostRequest() {

        final File file = createFileFromAssetsFolder("1mb1.jpg");

        // get MIME type of multipart data
        String type = getMimeType(file);


        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create(
                        MediaType.parse(type),
                        file
                );

        //start loop
        Log.i(Retrofit_V2_POST_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(Retrofit_V2_POST_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), requestFile);
        for (int i = 0; i < 100; i++) {
            App.getInstance().getRetrofitInterface().uploadAttachment(body).enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    responseCounter++;
                    Log.i("Upload", "success");
                    if (responseCounter == 99) {
                        finish();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e("Upload error:", t.getMessage());
                    finish();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(Retrofit_V2_POST_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    //@DebugLog
    @NonNull
    static String getMimeType(@NonNull File file) {
        String type = null;
        final String url = file.toString();
        final String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        if (type == null) {
            type = "*/*"; // fallback type.
        }
        return type;
    }

    // Use this method to create new file object from asset folder
    //@DebugLog
    public File createFileFromAssetsFolder(String name) {

        File f = new File(getCacheDir() + "/" + name);
        if (!f.exists())
            try {

                InputStream is = getAssets().open(name);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();

                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        return f;
    }

}
