package com.ut.berkerdemirer.asynchttp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    private int responseCounter = 0;

    private static final String AsyncHttpClient_V2_POST_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V2_POST_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V2_POST_LOOP_STARTED = "Loop Started";

  //  private static final String AsyncHttpClient_V2_POST_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AsyncHttpClient_V2_POST_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        postMultipartContent();
    }


    public void postMultipartContent() {

        File f = createFileFromAssetsFolder("1mb1.jpg");
        String fileType = getMimeType(f);
        RequestParams params = new RequestParams();
        try {
            params.put("file", f);
            params.setForceMultipartEntityContentType(true);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //start loop
        Log.i(AsyncHttpClient_V2_POST_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(AsyncHttpClient_V2_POST_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            App.getInstance().getClient().post("https://desolate-beach-17272.herokuapp.com/uploadFile", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    Log.d("success Response", "" + statusCode);
                    responseCounter++;
                    if (responseCounter == 99) {
                        finish();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Log.d("error", error.toString());
                    finish();
                }
            });
        }
    }

    @NonNull
    static String getMimeType(@NonNull File file) {
        String type = null;
        final String url = file.toString();
        final String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        if (type == null) {
            type = "*/*"; // fallback type.
        }
        return type;
    }

    // Use this method to create new file object from asset folder
    public File createFileFromAssetsFolder(String name) {

        File f = new File(getCacheDir() + "/" + name);
        if (!f.exists())
            try {

                InputStream is = getAssets().open(name);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();

                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        return f;
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(AsyncHttpClient_V2_POST_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
