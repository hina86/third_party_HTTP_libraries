# android-networking-okHttp

References

https://stackoverflow.com/questions/38217201/making-http-request-using-okhttp-library-inside-doinbackground-of-asynctask-bl

https://guides.codepath.com/android/Creating-and-Executing-Async-Tasks

https://github.com/square/okhttp/wiki/Recipes
