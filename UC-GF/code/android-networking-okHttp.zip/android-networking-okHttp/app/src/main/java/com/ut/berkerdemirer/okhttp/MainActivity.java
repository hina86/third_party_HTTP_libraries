package com.ut.berkerdemirer.okhttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.io.IOException;

import hugo.weaving.DebugLog;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {

    private int responseCounter = 0;

    private static final String ACTIVITY_STARTED = "Activity Started";
    private static final String ACTIVITY_ENDED = "Activity Ended";

    private static final String OkHttp_V1_GET_LOOP_STARTED = "Loop Started";

   // private static final String OkHttp_V1_GET_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);

        //download file async
        makeGetRequest();
    }

    //@DebugLog
    public void makeGetRequest() {

        //file to be downloaded
        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg";
        Request request = new Request.Builder().url(url).build();

        //start loop
        Log.i(OkHttp_V1_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
      //  Log.i(OkHttp_V1_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            App.getInstance().getClient().newCall(request).enqueue(new Callback() {
                //when error occurs throw and exception
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                    finish();
                }

                // when the response is successfully get
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    responseCounter += 1;
                    ResponseBody responseBody = response.body();
                    // if there is no problem just log the response bytes
                    Log.i("SUCCESS", "" + responseBody.bytes().length);

                    if (responseCounter == 99) {
                        //terminate app
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //garbage collector
        //System.gc();
        //end the app
        Log.i(ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
