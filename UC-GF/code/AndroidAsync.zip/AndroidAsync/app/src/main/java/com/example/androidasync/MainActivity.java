package com.example.androidasync;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.callback.HttpConnectCallback;

public class MainActivity extends AppCompatActivity {


    private int responseCounter = 0;

    private static final String ACTIVITY_STARTED = "Activity Started";
    private static final String ACTIVITY_ENDED = "Activity Ended";

    private static final String AndroidAsync_V1_GET_LOOP_STARTED = "Loop Started";

 //   private static final String AndroidAsync_V1_GET_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getFile();
    }

    public void getFile() {
        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg";

        //start loop
        Log.i(AndroidAsync_V1_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
        //System.gc();

        // Memory usage before the for loop
       // Log.i(AndroidAsync_V1_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 100; i++) {
            AsyncHttpClient.getDefaultInstance().execute(url, new HttpConnectCallback() {
                @Override
                public void onConnectCompleted(Exception ex, AsyncHttpResponse response) {
                    responseCounter++;
                    Log.d("Success response", response.code() + "");
                    if (responseCounter == 99) {
                        //terminate app
                        finish();
                    } else if(ex != null){
                        finish();
                    }
                }
            });
        }

    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
