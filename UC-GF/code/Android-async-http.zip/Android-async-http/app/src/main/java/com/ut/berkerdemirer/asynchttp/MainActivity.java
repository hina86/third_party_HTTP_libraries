package com.ut.berkerdemirer.asynchttp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.DataAsyncHttpResponseHandler;
import com.loopj.android.http.FileAsyncHttpResponseHandler;

import java.io.File;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    private int responseCounter = 0;

    private static final String ACTIVITY_STARTED = "Activity Started";
    private static final String ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V1_GET_LOOP_STARTED = "Loop Started";

    //private static final String AsyncHttpClient_V1_GET_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
       // for (int i = 0; i < 100; i++) {
        getMultipartContent(); //}
    }


    public void getMultipartContent() {

        //start loop
        Log.i(AsyncHttpClient_V1_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
        //Log.i(AsyncHttpClient_V1_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

         for (int i = 0; i < 100; i++) {
            App.getInstance().getClient().get("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg", new FileAsyncHttpResponseHandler(this) {
                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, File file) {
                    Log.d("failed ", "" + statusCode);
                   finish();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, File file) {
                    Log.d("Success ", "" + statusCode);
                    responseCounter++;
                   if (responseCounter == 99) {
                       finish();
                    }
                }
            });
       }
    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
