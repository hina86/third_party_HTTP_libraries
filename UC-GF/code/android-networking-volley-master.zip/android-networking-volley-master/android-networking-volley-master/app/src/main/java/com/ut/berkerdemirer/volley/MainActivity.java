package com.ut.berkerdemirer.volley;

import android.app.ActivityManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;

public class MainActivity extends AppCompatActivity {

    int responseCounter = 0;

    private static final String ACTIVITY_STARTED = "Activity Started";
    private static final String ACTIVITY_ENDED = "Activity Ended";

    private static final String Volley_V1_GET_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V1_GET_MEMORY_BEFORE = "Memory Before";


    // File to be uploaded
    //private String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg";
    //File to be downloaded
    private String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        //call the function
        makeGetRequest(url);
    }


    public void makeGetRequest(final String url) {

        //start loop
        Log.i(Volley_V1_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));


        //garbage collector
       // System.gc();

        // Memory usage before the for loop
        //Log.i(Volley_V1_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            VolleyHandler request = new VolleyHandler(Request.Method.GET, url,
                    new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            // handle the response

                            try {
                                Log.d("success", "" + response.length);
                                responseCounter++;
                                if (responseCounter == 99) {
                                    finish();
                                }

                            } catch (Exception e) {
                                finish();
                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    //handle the error
                    error.printStackTrace();
                    finish();
                }
            });
            VolleySingleton.getInstance(this).getRequestQueue().add(request);
        }
    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));

    }


}
