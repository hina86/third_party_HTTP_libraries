package com.ut.berkerdemirer.volley;


import android.support.annotation.Nullable;
import android.util.Log;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;

import java.util.Map;


// This class is implemented to be able to get volley requests as byte array.
public class VolleyHandler extends Request<byte[]> {

    private final Response.Listener<byte[]> mListener;

    //create a static map for directly accessing headers
    public Map<String, String> responseHeaders;

    //constructor
    public VolleyHandler(int method, String url, Response.Listener<byte[]> listener, @Nullable Response.ErrorListener errorListener) {
        super(method, url, errorListener);
        this.mListener = listener;
    }


    //parseNetworkResponse() takes as its parameter a NetworkResponse, which contains the response payload as a byte[], HTTP status code, and response headers.
    @Override
    protected Response<byte[]> parseNetworkResponse(NetworkResponse response) {

        //Initialise local responseHeaders map with response headers received
        responseHeaders = response.headers;

        //Pass the response data here

        return Response.success(response.data, HttpHeaderParser.parseCacheHeaders(response));

    }

    //callback interface
    // Volley calls you back on the main thread with the object you returned in parseNetworkResponse().
    @Override
    protected void deliverResponse(byte[] response) {
        mListener.onResponse(response);
    }



}
