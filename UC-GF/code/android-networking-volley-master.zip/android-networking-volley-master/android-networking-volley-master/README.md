# android-networking-volley

References

https://stackoverflow.com/questions/20675072/volley-and-asynctask
https://mobikul.com/downloading-files-using-volley/
https://developer.android.com/training/volley/request-custom
