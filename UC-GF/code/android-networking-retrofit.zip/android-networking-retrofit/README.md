# android-networking-retrofit

This tutorial is followed while implementing the code

https://futurestud.io/tutorials/retrofit-2-how-to-download-files-from-server

