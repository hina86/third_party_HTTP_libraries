package com.ut.berkerdemirer.myapplication;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

public interface RetrofitInterface  {


    // Always use ResponseBody when downloading a file otherwise Retrofit tries to parse the response which makes no sense
    @GET
    //pass a dynamic value as full URL to the request call
    Call<ResponseBody> downloadFileByUrl(@Url String fileUrl);

}
