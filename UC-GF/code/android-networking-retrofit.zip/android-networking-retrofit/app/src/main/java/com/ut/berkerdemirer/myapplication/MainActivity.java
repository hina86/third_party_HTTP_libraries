package com.ut.berkerdemirer.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    // Call size for multiple requests
    int responseCounter = 0;

    private static final String ACTIVITY_STARTED = "Activity Started";
    private static final String ACTIVITY_ENDED = "Activity Ended";

    private static final String Retrofit_V1_GET_LOOP_STARTED = "Loop Started";

   // private static final String Retrofit_V1_GET_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i(ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        makeGetRequest();
    }

    //@DebugLog
    public void makeGetRequest() {

        //start loop
        Log.i(Retrofit_V1_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(Retrofit_V1_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 100; i++) {
            App.getInstance().getRetrofitInterface().downloadFileByUrl("downloadFile/1mb1.jpg").enqueue(new Callback<ResponseBody>() {

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.d("error", "" + t);
                    finish();
                }

                // when the response is successfully get
                @Override
                public void onResponse(Call<ResponseBody> call, final Response<ResponseBody> response) {
                    responseCounter += 1;
                    // if there is no problem just log the response bytes
                    try {
                        Log.d("Success", " " + response.body().bytes().length);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (responseCounter == 99) {
                        //terminate app
                        Log.d("Counter", "" + responseCounter);
                        finish();

                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));

    }
}
