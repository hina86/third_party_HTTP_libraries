package com.ut.berkerdemirer.myapplication;

import android.app.Application;

import retrofit2.Retrofit;

public class App extends Application {

    RetrofitInterface retrofitInterface;
    Retrofit.Builder retBuilder;
    Retrofit retrofit;
    private static App sInstance = null;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        retBuilder = new Retrofit.Builder().baseUrl("https://desolate-beach-17272.herokuapp.com/");
        retrofit = retBuilder.build();
        retrofitInterface = retrofit.create(RetrofitInterface.class);
    }

    public static App getInstance() {
        return sInstance;
    }

    public RetrofitInterface getRetrofitInterface() {
        return retrofitInterface;
    }
}
