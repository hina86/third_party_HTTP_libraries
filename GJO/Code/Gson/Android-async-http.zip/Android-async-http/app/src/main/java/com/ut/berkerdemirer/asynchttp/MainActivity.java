package com.ut.berkerdemirer.asynchttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.ut.berkerdemirer.asynchttp.model.Lecturer;
import com.ut.berkerdemirer.asynchttp.model.TimeTable;
import com.ut.berkerdemirer.asynchttp.model.TimeTableWrapper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    TimeTableWrapper timeTableWrapper;
    ArrayList<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    //JSONArray arr = new JSONArray(  );
    private int responseCounter = 0;

    private static final String AsyncHttpClient_V4_DESERIALIZE_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V4_DESERIALIZE_GSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V4_DESERIALIZE_GSON_LOOP_STARTED = "Loop Started";

   // private static final String AsyncHttpClient_V4_DESERIALIZE_GSON_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AsyncHttpClient_V4_DESERIALIZE_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJSON();
    }

    public void getJSON() {

        final Gson gson = new GsonBuilder().create();

        //start loop
        Log.i(AsyncHttpClient_V4_DESERIALIZE_GSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();
        //https://desolate-beach-17272.herokuapp.com/downloadFile/jsonObj

        // Memory usage before the for loop
       // Log.i(AsyncHttpClient_V4_DESERIALIZE_GSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));
// DUE to limited RAM size in phone 100 post request (each deserailizing 1MB data) cannot be made. therefore we set the post request number to 30
        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().get("https://desolate-beach-17272.herokuapp.com/downloadFile/test.json", new JsonHttpResponseHandler() {

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    //super.onSuccess(statusCode, headers, response);
                    responseCounter++;
                    Type listOfMyClassObject = new TypeToken<ArrayList<TimeTableWrapper>>() {}.getType();
                    outputList = gson.fromJson(response.toString(), listOfMyClassObject);

                   // timeTableWrapper = gson.fromJson(response.toString().trim(), TimeTableWrapper.class);

                    Log.d("response", responseCounter + "  " + statusCode );
                    if (responseCounter == 29) {
                       // String str = response.toString();

                        //outputList = gson.fromJson( arr.toString(), listOfMyClassObject);
                        Log.d("response list size" , String.valueOf( outputList.size() ) );
                       // Log.d("response list type" , String.valueOf( listOfMyClassObject ) );

                        finish();
                    }
                    //outputList = null;
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    super.onFailure(statusCode, headers, throwable, errorResponse);
                    finish();
                }
            });
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  System.gc();
        //end the app
       // System.out.println( List );
        Log.i(AsyncHttpClient_V4_DESERIALIZE_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }


}
