package com.ut.berkerdemirer.volley;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.ut.berkerdemirer.volley.model.TimeTableWrapper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    int responseCounter = 0;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String Volley_V4_DESERIALIZE_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String Volley_V4_DESERIALIZE_GSON_ACTIVITY_ENDED = "Activity Ended";
    private String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
    private static final String Volley_V4_DESERIALIZE_GSON_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V4_DESERIALIZE_GSON_MEMORY_BEFORE = "Memory Before";

    TimeTableWrapper timeTableWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Volley_V4_DESERIALIZE_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJson(url);
    }


    // get the json object from server and deserialize it and map it to the java object
    //@DebugLog

    public void getJson(final String url) {
        RequestQueue queue = Volley.newRequestQueue( this );
        final Gson gson = new GsonBuilder().create();


        //start loop
        Log.i(Volley_V4_DESERIALIZE_GSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
     //   Log.i(Volley_V4_DESERIALIZE_GSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 30; i++) {


          //  ******
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                           // Log.e( "onResponse", "" + response );

                                // JsonObjectRequest jsonObjReq = new JsonObjectRequest( url,new Response.Listener<JSONArray>() {
                                //   @Override
                                // public void onResponse(JSONArray response) {

                                Type listOfMyClassObject = new TypeToken<ArrayList<TimeTableWrapper>>() {
                                }.getType();
                                outputList = gson.fromJson( response, listOfMyClassObject );
                                //timeTableWrapper = gson.fromJson(response, TimeTableWrapper.class);
                                //System.out.println(timeTableWrapper);
                                responseCounter++;
                                Log.d( "Response", String.valueOf( responseCounter ) );
                                if (responseCounter == 29) {
                                    Log.d( "response list size", String.valueOf( outputList.size() ) );
                                    finish();
                                }



                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    finish();
                }
            });
            VolleySingleton.getInstance(this).getRequestQueue().add(stringRequest);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  System.gc();
        //end the app
        Log.i(Volley_V4_DESERIALIZE_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
