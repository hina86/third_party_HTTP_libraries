package com.example.androidasync;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.androidasync.model.TimeTableWrapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpGet;
import com.koushikdutta.async.http.AsyncHttpRequest;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.callback.HttpConnectCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

   // List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private int responseCounter = 0;
    TimeTableWrapper timeTableWrapper;
    private static final String AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String AndroidAsync_V6_DESERIALIZE_GSON_LOOP_STARTED = "Loop Started";

    //private static final String AndroidAsync_V6_DESERIALIZE_GSON_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getFile();
    }

    public void getFile() {
        final String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
        final Gson gson = new GsonBuilder().create();
        AsyncHttpGet asyncHttpGet = new AsyncHttpGet(url);

        //start loop
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
        //System.gc();

        // Memory usage before the for loop
       // Log.i(AndroidAsync_V6_DESERIALIZE_GSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 30; i++) {
            AsyncHttpClient.getDefaultInstance().executeJSONArray(asyncHttpGet, new AsyncHttpClient.JSONArrayCallback() {
                @Override
                public void onCompleted(Exception e, AsyncHttpResponse source, JSONArray result) {
                    Type listOfMyClassObject = new TypeToken<ArrayList<TimeTableWrapper>>() {}.getType();
                    //outputList =
                            gson.fromJson(result.toString(), listOfMyClassObject);

                    //timeTableWrapper = gson.fromJson(result.toString(), TimeTableWrapper.class);
                    responseCounter++;
                    Log.d("response", "" + responseCounter);
                    if (responseCounter == 29) {

                     //   Log.i("SUCCESS list size", "" + outputList.size());
                        finish();
                    } else if (e != null) {
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
