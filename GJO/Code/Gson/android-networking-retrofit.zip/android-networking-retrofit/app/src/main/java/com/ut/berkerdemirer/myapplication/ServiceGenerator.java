package com.ut.berkerdemirer.myapplication;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

public class ServiceGenerator {

    private static final String BASE_URL = "https://desolate-beach-17272.herokuapp.com/";

    private static Retrofit.Builder builder = new Retrofit.Builder().baseUrl(BASE_URL);

    private static Retrofit retrofit = builder.build();

    public static <S> S createService( Class<S> serviceClass) { return retrofit.create(serviceClass); }
}
