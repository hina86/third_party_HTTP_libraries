package com.ut.berkerdemirer.myapplication;

import android.app.Application;

public class App extends Application {

    RetrofitInterface retrofitInterface;

    private static App sInstance = null;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        retrofitInterface = ServiceGenerator.createService(RetrofitInterface.class);
    }

    public static App getInstance() {
        return sInstance;
    }

    public RetrofitInterface getRetrofitInterface() {
        return retrofitInterface;
    }
}
