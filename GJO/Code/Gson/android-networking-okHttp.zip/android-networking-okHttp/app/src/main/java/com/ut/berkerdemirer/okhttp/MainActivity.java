package com.ut.berkerdemirer.okhttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ut.berkerdemirer.okhttp.model.TimeTableWrapper;

import org.json.JSONArray;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {

    int responseCounter = 0;
    ArrayList<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String OkHttp_V4_Deserialize_GET_ACTIVITY_STARTED = "Activity Started";
    private static final String OkHttp_V4_Deserialize_GET_ACTIVITY_ENDED = "Activity Ended";

    private static final String OkHttp_V4_Deserialize_GET_LOOP_STARTED = "Loop Started";
   // private static final String OkHttp_V4_Deserialize_GET_LOOP_ENDED = "Loop Ended";

   // private static final String OkHttp_V4_Deserialize_GET_MEMORY_BEFORE = "Memory Before";
   // private static final String OkHttp_V4_Deserialize_GET_MEMORY_AFTER = "Memory After";

    TimeTableWrapper timeTableWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(OkHttp_V4_Deserialize_GET_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        makeGetRequest();

    }

    //@DebugLog
    public void makeGetRequest() {
        final Gson gson = new GsonBuilder().create();
        //file to be downloaded
        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
        Request request = new Request.Builder().url(url).build();

        //start loop
        Log.i(OkHttp_V4_Deserialize_GET_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(OkHttp_V4_Deserialize_GET_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().newCall(request).enqueue(new Callback() {
                //when error occurs throw and exception
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();

                    finish();
                }

                // when the response is successfully get
                @Override
                public void onResponse(Call call, Response response) throws IOException {



                    Type listOfMyClassObject = new TypeToken<ArrayList<TimeTableWrapper>>() {}.getType();
                    outputList = gson.fromJson(response.body().string(), listOfMyClassObject);
                    //timeTableWrapper = gson.fromJson(response.body().string(), TimeTableWrapper.class);
                    // if there is no problem just log the response bytes
                    responseCounter += 1;
                    Log.i("SUCCESS", "" + responseCounter);
                    if (responseCounter == 29) {
                        //terminate app
                        Log.i("SUCCESS list size", "" + outputList.size());
                       // Log.i("SUCCESS list", "" + outputList);
                        finish();
                    }
                    outputList = null;
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(OkHttp_V4_Deserialize_GET_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));

        android.os.Process.killProcess(android.os.Process.myPid());
        //garbage collector
       // System.gc();

        //memory usage after for loop
       // Log.i(OkHttp_V4_Deserialize_GET_MEMORY_AFTER, String.valueOf(System.currentTimeMillis()));

        // Loop end log
       // Log.i(OkHttp_V4_Deserialize_GET_LOOP_ENDED, String.valueOf(System.currentTimeMillis()));
    }
}
