package com.example.androidasync;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.androidasync.model.TimeTableWrapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpGet;
import com.koushikdutta.async.http.AsyncHttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private int responseCounter = 0;
    TimeTableWrapper timeTableWrapper;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_STARTED = "Activity Started";
    private static final String AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String AndroidAsync_V6_DESERIALIZE_GSON_LOOP_STARTED = "Loop Started";

  //  private static final String AndroidAsync_V6_DESERIALIZE_GSON_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getFile();
    }

    public void getFile() {
        final String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
        final ObjectMapper mapper = new ObjectMapper();
       // mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AsyncHttpGet asyncHttpGet = new AsyncHttpGet(url);

        //start loop
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
       // Log.i(AndroidAsync_V6_DESERIALIZE_GSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 0; i < 30; i++) {
            AsyncHttpClient.getDefaultInstance().executeJSONArray(asyncHttpGet, new AsyncHttpClient.JSONArrayCallback() {
                @Override
                public void onCompleted(Exception e, AsyncHttpResponse source, JSONArray result) {

                    try {
                        outputList = mapper.readValue(result.toString(),new TypeReference<List<TimeTableWrapper>>() {});
                        //timeTableWrapper = mapper.readValue(String.valueOf(result), TimeTableWrapper.class);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    responseCounter++;
                    Log.d("response", "" + responseCounter);
                    if (responseCounter == 29) {
                        Log.d("response list size", String.valueOf( outputList.size() ) );
                        finish();
                    } else if (e != null) {
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  System.gc();
        //end the app
        Log.i(AndroidAsync_V6_DESERIALIZE_GSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
