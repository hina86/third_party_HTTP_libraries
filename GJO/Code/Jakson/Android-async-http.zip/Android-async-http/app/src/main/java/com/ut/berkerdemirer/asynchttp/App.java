package com.ut.berkerdemirer.asynchttp;

import android.app.Application;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;

public class App extends Application {

    //instance of okHttp client
    private AsyncHttpClient client;
    private static App sInstance = null;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        client = new AsyncHttpClient();
        client.setTimeout(1000000);
        client.setLoggingLevel( Log.ERROR);
        client.setLoggingLevel( Log.DEBUG);
    }

    public AsyncHttpClient getClient() {
        return client;
    }

    public static App getInstance() {
        return sInstance;
    }

}
