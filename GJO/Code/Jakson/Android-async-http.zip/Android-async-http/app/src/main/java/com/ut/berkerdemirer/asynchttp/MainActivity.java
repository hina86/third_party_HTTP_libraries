package com.ut.berkerdemirer.asynchttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.ut.berkerdemirer.asynchttp.model.TimeTableWrapper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    TimeTableWrapper timeTableWrapper;

    private int responseCounter = 0;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String AsyncHttpClient_V7_DESERIALIZE_JACKSON_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V7_DESERIALIZE_JACKSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V7_DESERIALIZE_JACKSON_LOOP_STARTED = "Loop Started";

    //private static final String AsyncHttpClient_V7_DESERIALIZE_JACKSON_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AsyncHttpClient_V7_DESERIALIZE_JACKSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJSON();
    }

    //@DebugLog
    public void getJSON() {

        final ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        //start loop
        Log.i(AsyncHttpClient_V7_DESERIALIZE_JACKSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(AsyncHttpClient_V7_DESERIALIZE_JACKSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().get("https://desolate-beach-17272.herokuapp.com/downloadFile/test.json", new JsonHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    //super.onSuccess(statusCode, headers, response);
                    responseCounter++;
                    try {
                       // List<TimeTableWrapper> javaType=mapper.getTypeFactory().constructType(TimeTableWrapper.class);
                      //  List<TimeTableWrapper> out = mapper.readValue(response.toString(),new TypeReference<List<TimeTableWrapper>>() {});
                        outputList = mapper.readValue(response.toString(),new TypeReference<List<TimeTableWrapper>>() {});
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Log.d("response", responseCounter + "  " + statusCode );
                    if (responseCounter == 29) {
                        Log.d("response list size", String.valueOf( outputList.size() ) );
                        finish();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    super.onFailure(statusCode, headers, throwable, errorResponse);
                    finish();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(AsyncHttpClient_V7_DESERIALIZE_JACKSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

}
