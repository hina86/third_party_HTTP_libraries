package com.ut.berkerdemirer.asynchttp.model;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("dailyTimeTable")
public class TimeTableWrapper {

    public final TimeTable timeTable;

    @JsonCreator
    public TimeTableWrapper(TimeTable timeTable) {
        this.timeTable = timeTable;
    }

    @Override
    public String toString() {
        return "TimeTableWrapper{" +
                "timeTable=" + timeTable +
                '}';
    }

    public TimeTable getTimeTable() {
        return timeTable;
    }
}
