package com.ut.berkerdemirer.myapplication.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StudyWorkType {

    @JsonProperty("code")
    private String code;
    @JsonProperty("et")
    private String et;
    @JsonProperty("en")
    private String en;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEt() {
        return et;
    }

    public void setEt(String et) {
        this.et = et;
    }

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    @Override
    public String toString() {
        return "StudyWorkType{" +
                "code='" + code + '\'' +
                ", et='" + et + '\'' +
                ", en='" + en + '\'' +
                '}';
    }
}
