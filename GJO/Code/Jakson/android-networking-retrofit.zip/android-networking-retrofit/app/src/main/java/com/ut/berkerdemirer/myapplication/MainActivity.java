package com.ut.berkerdemirer.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ut.berkerdemirer.myapplication.Model.TimeTableWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TimeTableWrapper timeTableWrapper;
    private int responseCounter = 0;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String Retrofit_V5_DESERIALIZE_JACKSON_ACTIVITY_STARTED = "Activity Started";
    private static final String Retrofit_V5_DESERIALIZE_JACKSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String Retrofit_V5_DESERIALIZE_JACKSON_LOOP_STARTED = "Loop Started";

  //  private static final String Retrofit_V5_DESERIALIZE_JACKSON_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Retrofit_V5_DESERIALIZE_JACKSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        makeRequest();
    }

    //@DebugLog
    private void makeRequest() {

        //start loop
        Log.i(Retrofit_V5_DESERIALIZE_JACKSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(Retrofit_V5_DESERIALIZE_JACKSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getRetrofitInterface().downloadFileByUrl("downloadFile/test.json").enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    ObjectMapper mapper = new ObjectMapper();
                   // mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
                    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                    try {
                        outputList = mapper.readValue(response.body().string(),new TypeReference<List<TimeTableWrapper>>() {});
                     //   timeTableWrapper = mapper.readValue(response.body().string(), TimeTableWrapper.class);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    responseCounter += 1;
                    Log.d("Success", "" +  responseCounter);
                    if (responseCounter == 29) {
                        Log.d("response list size", String.valueOf( outputList.size() ) );
                        finish();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e("Download error:", t.getMessage());
                    finish();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  System.gc();
        //end the app
        Log.i(Retrofit_V5_DESERIALIZE_JACKSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

}
