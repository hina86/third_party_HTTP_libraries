package com.ut.berkerdemirer.okhttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ut.berkerdemirer.okhttp.model.TimeTableWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    TimeTableWrapper timeTableWrapper;
    int responseCounter = 0;

    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String OkHttp_V6_Deserialize_Jackson_ACTIVITY_STARTED = "Activity Started";
    private static final String OkHttp_V6_Deserialize_Jackson_ACTIVITY_ENDED = "Activity Ended";

    private static final String OkHttp_V6_Deserialize_Jackson_LOOP_STARTED = "Loop Started";

   // private static final String OkHttp_V6_Deserialize_Jackson_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i(OkHttp_V6_Deserialize_Jackson_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);
        makeGetRequest();
    }

    //@DebugLog
    public void makeGetRequest() {

        //file to be downloaded
        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
        Request request = new Request.Builder().url(url).build();

        //start loop
        Log.i(OkHttp_V6_Deserialize_Jackson_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(OkHttp_V6_Deserialize_Jackson_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().newCall(request).enqueue(new Callback() {
                //when error occurs throw and exception
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                    finish();
                }

                // when the response is successfully get
                @Override
                public void onResponse(Call call, Response response) {

                    ObjectMapper mapper = new ObjectMapper();
                    //mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
                    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                    try {
                        outputList = mapper.readValue(response.body().string(),new TypeReference<List<TimeTableWrapper>>() {});
                      //  timeTableWrapper = mapper.readValue(response.body().string(), TimeTableWrapper.class);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    responseCounter += 1;
                    // if there is no problem just log the response bytes
                    Log.i("SUCCESS", "" + responseCounter);

                    if (responseCounter == 29) {
                        //terminate app
                        Log.d("response list size", String.valueOf( outputList.size() ) );
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        //garbage collector
        //System.gc();

        //memory usage after for loop
        Log.i(OkHttp_V6_Deserialize_Jackson_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());

    }
}
