package com.ut.berkerdemirer.volley.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class TimeTable {

    @JsonProperty("course_uuid")
    private String course_uuid;
    @JsonProperty("eventType")
    private EventType eventType = new EventType();
    @JsonProperty("state")
    private State state = new State();
    @JsonProperty("studyWorkType")
    private StudyWorkType studyWorkType = new StudyWorkType();
    @JsonProperty("lecturers")
    private ArrayList<Lecturer> lecturers = new ArrayList<>();
    @JsonProperty("time")
    private Time time = new Time();
    @JsonProperty("location")
    private Location location = new Location();

    public String getCourse_uuid() {
        return course_uuid;
    }

    public void setCourse_uuid(String course_uuid) {
        this.course_uuid = course_uuid;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public StudyWorkType getStudyWorkType() {
        return studyWorkType;
    }

    public void setStudyWorkType(StudyWorkType studyWorkType) {
        this.studyWorkType = studyWorkType;
    }

    public ArrayList<Lecturer> getLecturers() {
        return lecturers;
    }

    public void setLecturers(ArrayList<Lecturer> lecturers) {
        this.lecturers = lecturers;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "TimeTable{" +
                "course_uuid='" + course_uuid + '\'' +
                ", eventType=" + eventType +
                ", state=" + state +
                ", studyWorkType=" + studyWorkType +
                ", lecturers=" + lecturers +
                ", time=" + time +
                ", location=" + location +
                '}';
    }
}
