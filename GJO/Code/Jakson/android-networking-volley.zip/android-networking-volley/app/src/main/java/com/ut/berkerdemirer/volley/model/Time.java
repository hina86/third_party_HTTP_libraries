package com.ut.berkerdemirer.volley.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Time {

    @JsonProperty("weekDay")
    private WeekDay weekDay = new WeekDay();
    @JsonProperty("academic_weeks")
    private String academic_weeks;
    @JsonProperty("since_date")
    private String since_date;
    @JsonProperty("until_date")
    private String until_date;
    @JsonProperty("begin_time")
    private String begin_time;
    @JsonProperty("end_time")
    private String end_time;

    public WeekDay getWeekDay() {
        return weekDay;
    }

    public void setWeekDay(WeekDay weekDay) {
        this.weekDay = weekDay;
    }

    public String getAcademic_weeks() {
        return academic_weeks;
    }

    public void setAcademic_weeks(String academic_weeks) {
        this.academic_weeks = academic_weeks;
    }

    public String getSince_date() {
        return since_date;
    }

    public void setSince_date(String since_date) {
        this.since_date = since_date;
    }

    public String getUntil_date() {
        return until_date;
    }

    public void setUntil_date(String until_date) {
        this.until_date = until_date;
    }

    public String getBegin_time() {
        return begin_time;
    }

    public void setBegin_time(String begin_time) {
        this.begin_time = begin_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    @Override
    public String toString() {
        return "Time{" +
                "weekDay=" + weekDay +
                ", academic_weeks='" + academic_weeks + '\'' +
                ", since_date='" + since_date + '\'' +
                ", until_date='" + until_date + '\'' +
                ", begin_time='" + begin_time + '\'' +
                ", end_time='" + end_time + '\'' +
                '}';
    }
}
