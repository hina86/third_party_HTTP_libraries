package com.ut.berkerdemirer.volley;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ut.berkerdemirer.volley.model.TimeTableWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    int responseCounter = 0;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String Volley_V7_DESERIALIZE_JACKSON_ACTIVITY_STARTED = "Activity Started";
    private static final String Volley_V7_DESERIALIZE_JACKSON_ACTIVITY_ENDED = "Activity Ended";

    private static final String Volley_V7_DESERIALIZE_JACKSON_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V7_DESERIALIZE_JACKSON_MEMORY_BEFORE = "Memory Before";

    TimeTableWrapper timeTableWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Volley_V7_DESERIALIZE_JACKSON_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJson();
    }


    // get the json object from server and deserialize it and map it to the java object
    public void getJson() {


        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";
        final ObjectMapper mapper = new ObjectMapper();

        //start loop
        Log.i(Volley_V7_DESERIALIZE_JACKSON_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(Volley_V7_DESERIALIZE_JACKSON_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
                            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                            try {
                                outputList = mapper.readValue(response,new TypeReference<List<TimeTableWrapper>>() {});
                               // timeTableWrapper = mapper.readValue(response, TimeTableWrapper.class);
                                responseCounter++;
                                Log.d("response", "" + responseCounter);
                                if (responseCounter == 29) {
                                    Log.d("response list size", String.valueOf( outputList.size() ) );
                                    finish();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                                finish();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    finish();
                }
            });
            VolleySingleton.getInstance(this).getRequestQueue().add(stringRequest);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(Volley_V7_DESERIALIZE_JACKSON_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
