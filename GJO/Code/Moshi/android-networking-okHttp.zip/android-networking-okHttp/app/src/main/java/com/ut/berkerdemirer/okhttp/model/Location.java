package com.ut.berkerdemirer.okhttp.model;


public class Location {

    private String location_uuid;
    private String address;

    public String getLocation_uuid() {
        return location_uuid;
    }

    public void setLocation_uuid(String location_uuid) {
        this.location_uuid = location_uuid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Location{" +
                "location_uuid='" + location_uuid + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
