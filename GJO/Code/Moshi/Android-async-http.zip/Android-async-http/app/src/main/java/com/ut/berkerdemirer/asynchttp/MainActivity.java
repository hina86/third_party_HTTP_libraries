package com.ut.berkerdemirer.asynchttp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.Types;
import com.ut.berkerdemirer.asynchttp.model.TimeTableWrapper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import hugo.weaving.DebugLog;

public class MainActivity extends AppCompatActivity {


    TimeTableWrapper timeTableWrapper;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private int responseCounter = 0;

    private static final String AsyncHttpClient_V6_DESERIALIZE_MOSHI_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V6_DESERIALIZE_MOSHI_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V6_DESERIALIZE_MOSHI_LOOP_STARTED = "Loop Started";

  //  private static final String AsyncHttpClient_V6_DESERIALIZE_MOSHI_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(AsyncHttpClient_V6_DESERIALIZE_MOSHI_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJSON();
    }

    //@DebugLog
    public void getJSON() {

        final Moshi moshi = new Moshi.Builder().build();

        //start loop
        Log.i(AsyncHttpClient_V6_DESERIALIZE_MOSHI_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(AsyncHttpClient_V6_DESERIALIZE_MOSHI_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getClient().get("https://desolate-beach-17272.herokuapp.com/downloadFile/test.json", new JsonHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    //super.onSuccess(statusCode, headers, response);
                    responseCounter++;
                   /* Type type = Types.newParameterizedType(Types.getRawType( ArrayList<TimeTableWrapper> ));
                    JsonAdapter<ArrayList<TimeTableWrapper>> jsonAdapter = moshi.adapter(type);
                   // JsonAdapter<TimeTableWrapper> jsonAdapter = moshi.adapter(TimeTableWrapper.class);
                    try {

                        outputList = jsonAdapter.fromJson( ( response.toString() ) );*/


                        try {


                            Type listMyData = Types.newParameterizedType(List.class, TimeTableWrapper.class);
                            JsonAdapter<List<TimeTableWrapper>> adapter = moshi.adapter(listMyData);
                            outputList = adapter.fromJson(response.toString());


                        Log.d("response", responseCounter + "");
                        if (responseCounter == 29) {
                            Log.d("response list size" , String.valueOf( outputList.size() ) );
                            finish();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    super.onFailure(statusCode, headers, throwable, errorResponse);
                    finish();
                }
            });
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //System.gc();
        //end the app
        Log.i(AsyncHttpClient_V6_DESERIALIZE_MOSHI_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

}
