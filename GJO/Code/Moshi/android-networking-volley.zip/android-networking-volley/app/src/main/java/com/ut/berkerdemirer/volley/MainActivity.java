package com.ut.berkerdemirer.volley;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.Types;
import com.ut.berkerdemirer.volley.model.TimeTableWrapper;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    int responseCounter = 0;

    private static final String Volley_V8_DESERIALIZE_MOSHI_ACTIVITY_STARTED = "Activity Started";
    private static final String Volley_V8_DESERIALIZE_MOSHI_ACTIVITY_ENDED = "Activity Ended";

    private static final String Volley_V8_DESERIALIZE_MOSHI_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V8_DESERIALIZE_MOSHI_MEMORY_BEFORE = "Memory Before";
   List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    TimeTableWrapper timeTableWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Volley_V8_DESERIALIZE_MOSHI_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        getJson();
    }


    // get the json object from server and deserialize it and map it to the java object
    public void getJson() {

        final Moshi moshi = new Moshi.Builder().build();
        String url = "https://desolate-beach-17272.herokuapp.com/downloadFile/test.json";

        //start loop
        Log.i(Volley_V8_DESERIALIZE_MOSHI_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
     //   Log.i(Volley_V8_DESERIALIZE_MOSHI_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Type listMyData = Types.newParameterizedType( List.class, TimeTableWrapper.class);
                            JsonAdapter<List<TimeTableWrapper>> adapter = moshi.adapter(listMyData);
                            //JsonAdapter<TimeTableWrapper> jsonAdapter = moshi.adapter(TimeTableWrapper.class);
                            try {
                                responseCounter++;
                                outputList = adapter.fromJson(response);
                               // timeTableWrapper = jsonAdapter.fromJson(response);
                                Log.d("response", "" + responseCounter);
                                if (responseCounter == 29) {
                                    Log.d("response list size" , String.valueOf( outputList.size() ) );
                                    finish();
                                }

                            } catch (IOException e) {
                                e.printStackTrace();
                                finish();
                            }


                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    finish();
                }
            });

            VolleySingleton.getInstance(this).getRequestQueue().add(stringRequest);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(Volley_V8_DESERIALIZE_MOSHI_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());

    }

}
