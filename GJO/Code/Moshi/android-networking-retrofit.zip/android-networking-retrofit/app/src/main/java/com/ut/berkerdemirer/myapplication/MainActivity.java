package com.ut.berkerdemirer.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.Types;
import com.ut.berkerdemirer.myapplication.Model.TimeTableWrapper;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TimeTableWrapper timeTableWrapper;
    private int responseCounter = 0;
    List<TimeTableWrapper> outputList= new ArrayList<TimeTableWrapper>(  );
    private static final String Retrofit_V6_DESERIALIZE_MOSHI_ACTIVITY_STARTED = "Activity Started";
    private static final String Retrofit_V6_DESERIALIZE_MOSHI_ACTIVITY_ENDED = "Activity Ended";

    private static final String Retrofit_V6_DESERIALIZE_MOSHI_LOOP_STARTED = "Loop Started";

//    private static final String Retrofit_V6_DESERIALIZE_MOSHI_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(Retrofit_V6_DESERIALIZE_MOSHI_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        makeRequest();
    }
    //@DebugLog
    private void makeRequest() {

        //start loop
        Log.i(Retrofit_V6_DESERIALIZE_MOSHI_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
     //   System.gc();

        // Memory usage before the for loop
       // Log.i(Retrofit_V6_DESERIALIZE_MOSHI_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 0; i < 30; i++) {
            App.getInstance().getRetrofitInterface().downloadFileByUrl("downloadFile/test.json").enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    Moshi moshi = new Moshi.Builder().build();

                    //JsonAdapter<TimeTableWrapper> jsonAdapter = moshi.adapter(TimeTableWrapper.class);
                    try {
                        //String responseBodyString = response.body().string();
                        //timeTableWrapper = jsonAdapter.fromJson(responseBodyString);
                        Type listMyData = Types.newParameterizedType( List.class, TimeTableWrapper.class);
                        JsonAdapter<List<TimeTableWrapper>> adapter = moshi.adapter(listMyData);
                        outputList = adapter.fromJson(response.body().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    responseCounter += 1;
                    Log.d("Success", "" + responseCounter);
                    if (responseCounter == 29) {
                        Log.d("response list size" , String.valueOf( outputList.size() ) );
                        finish();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e("Download error:", t.getMessage());
                    finish();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.i(Retrofit_V6_DESERIALIZE_MOSHI_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

}
