package com.ut.berkerdemirer.picasso;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    int responseCounter = 0;
    private LinearLayout linearLayout;
    private static final String PICASSO_V1_ACTIVITY_STARTED = "Activity Started";
    private static final String PICASSO_V1_ACTIVITY_ENDED = "Activity Ended";

    private static final String PICASSO_V1_LOOP_STARTED = "Loop Started";

   // private static final String PICASSO_V1_MEMORY_BEFORE = "Memory Before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(PICASSO_V1_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));


        setContentView(R.layout.activity_main);

        // Create a LinearLayout instance from resource
        linearLayout = findViewById(R.id.linearLayout);

        // call method
        getImages("1");
    }

    // method for calling 10 images
    //@DebugLog
    public void getImages(String size) {

        // Log the time when App started
        Log.i(PICASSO_V1_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
        //System.gc();

        // Memory usage before the for loop
      //  Log.i(PICASSO_V1_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 1; i <= 100; i++) {

            // create layout parameters
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);

            // create image views programatically
            ImageView image = new ImageView(this);

            //set layout parameters to image view
            image.setLayoutParams(lp);
            // Adds the view to the layout
            linearLayout.addView(image);

            // get images using picasso library and put them into imageview using argb 8888 format
            Picasso.get().load("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg").config(Bitmap.Config.ARGB_8888).into(image, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {
                    Log.d("success", responseCounter + "");
                    responseCounter ++;
                    if (responseCounter == 99) {
                        finish();
                    }
                }
                @Override
                public void onError(Exception e) {

                    Log.d("ERROR",  "" + e);
                    finish();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //garbage collector
       // System.gc();
        Log.i(PICASSO_V1_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
