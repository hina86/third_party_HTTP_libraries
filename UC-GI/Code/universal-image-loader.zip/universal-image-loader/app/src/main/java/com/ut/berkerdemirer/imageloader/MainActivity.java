package com.ut.berkerdemirer.imageloader;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

public class MainActivity extends AppCompatActivity {

    private ImageLoader imageLoader;
    private LinearLayout linearLayout;
    private DisplayImageOptions options;

    private static final String ImageLoader_V1_ACTIVITY_STARTED = "Activity Started";
    private static final String ImageLoader_V1_ACTIVITY_ENDED = "Activity Ended";

    private static final String ImageLoader_V1_LOOP_STARTED = "Loop Started";
    private static final String ImageLoader_V1_LOOP_ENDED = "Loop Ended";

   // private static final String ImageLoader_V1_MEMORY_BEFORE = "Memory Before";
   // private static final String ImageLoader_V1_MEMORY_AFTER = "Memory After";

    int responseCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(ImageLoader_V1_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);

        //get singleton image loader
        imageLoader = ImageLoader.getInstance();
        ImageLoaderConfiguration imageLoaderConfiguration = new ImageLoaderConfiguration.Builder(this).build();
        imageLoader.init(imageLoaderConfiguration);

        //initialize linear layout from resources
        linearLayout = findViewById(R.id.linearLayout);

        // display options of UIL
        options = new DisplayImageOptions.Builder()
                .bitmapConfig(Bitmap.Config.ARGB_8888)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .build();

        getImages("1");
    }


    // method for downloading 10 images
    public void getImages(String size) {


        // Log the time when App started
        Log.i(ImageLoader_V1_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
       // Log.i(ImageLoader_V1_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));


        for (int i = 1; i <= 100; i++) {

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);

            // create new image view in each iteration and set layout parameters to it then add imageview to linear layout
            ImageView image = new ImageView(this);
            image.setLayoutParams(lp);
            // Adds the view to the layout
            linearLayout.addView(image);

            // image loader library's function for downloading images. size is parameterized
            imageLoader.displayImage("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg", image, options, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {

                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                    finish();
                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                    responseCounter++;
                    Log.d("Success", "" + responseCounter);
                    if (responseCounter == 100) {
                        finish();
                    }
                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {

                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        Log.i(ImageLoader_V1_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
