package com.ut.berkerdemirer.glide;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import hugo.weaving.DebugLog;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout;

    private static final String GLIDE_V1_ACTIVITY_STARTED = "Activity Started";
    private static final String GLIDE_V1_ACTIVITY_ENDED = "Activity Ended";

    private static final String GLIDE_V1_LOOP_STARTED = "Loop Started";
    private static final String GLIDE_V1_LOOP_ENDED = "Loop Ended";

   // private static final String GLIDE_V1_MEMORY_BEFORE = "Memory Before";
   // private static final String GLIDE_V1_MEMORY_AFTER = "Memory After";

    int responseCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Log when app is started
        Log.i(GLIDE_V1_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));

        setContentView(R.layout.activity_main);

        // create LinearLayout instance from Resource
        linearLayout = findViewById(R.id.linearLayout);
        for (int i = 1; i <= 100; i++) {
            // call method
            getImages( "1" );
        }
    }

    // method for getting 10 images from server
    //@DebugLog
    public void getImages(String size) {

        Log.i(GLIDE_V1_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
      //  System.gc();

        // Memory usage before the for loop
      //  Log.i(GLIDE_V1_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

       // for (int i = 1; i <= 100; i++) {

            // create layout parameters to correctly display image
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);

            // create imageViews programatically in each iteration
            ImageView image = new ImageView(this);

            // add layout parameters into iamge
            image.setLayoutParams(lp);
            // Adds the view to the layout
            linearLayout.addView(image);

            // Glide library function to get images from server using ARGB 8888. Size is parameterized
            Glide.with(this).load("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg")
                    .format(DecodeFormat.PREFER_ARGB_8888)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            finish();
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                            Log.d("success", responseCounter + "");
                            responseCounter ++;

                            if (responseCounter == 99) {
                                finish();
                            }
                            return false;
                        }
                    })
                    .into(image);


        //}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(GLIDE_V1_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
