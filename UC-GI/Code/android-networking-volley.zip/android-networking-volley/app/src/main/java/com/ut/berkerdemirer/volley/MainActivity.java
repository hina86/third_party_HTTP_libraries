package com.ut.berkerdemirer.volley;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout;
    int responseCounter = 0;

    private static final String Volley_V5_IMAGE_ACTIVITY_STARTED = "Activity Started";
    private static final String Volley_V5_IMAGE_ACTIVITY_ENDED = "Activity Ended";

    private static final String Volley_V5_IMAGE_LOOP_STARTED = "Loop Started";

   // private static final String Volley_V5_IMAGE_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(Volley_V5_IMAGE_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        linearLayout = findViewById(R.id.linearLayout);

        getImages("1");

    }

    //@DebugLog
    public void getImages(String size) {

        //start loop
        Log.d(Volley_V5_IMAGE_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
      //  Log.i(Volley_V5_IMAGE_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 1; i <= 100; i++) {

            // create layout parameters to correctly display image
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);

            // create imageViews programatically in each iteration
            final ImageView image = new ImageView(this);

            // add layout parameters into iamge
            image.setLayoutParams(lp);
            // Adds the view to the layout
            linearLayout.addView(image);
            //ImageRequest request = new ImageRequest("https://desolate-beach-17272.herokuapp.com/downloadFile/" + size + "mb" + i + ".jpg",

            ImageRequest request = new ImageRequest("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg",
                    new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            Log.d("response", responseCounter  +"");
                            responseCounter++;
                            if(responseCounter == 99){
                                finish();
                            }
                            image.setImageBitmap(bitmap);
                        }
                    }, 274, 365, Bitmap.Config.ARGB_8888,
                    new Response.ErrorListener() {
                        public void onErrorResponse(VolleyError error) {
                            finish();
                        }
                    });

          VolleySingleton.getInstance(this).getRequestQueue().add(request);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.d(Volley_V5_IMAGE_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
