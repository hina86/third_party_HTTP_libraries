package com.ut.berkerdemirer.asynchttp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.FileAsyncHttpResponseHandler;

import java.io.File;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout;

    private int responseCounter = 0;

    private static final String AsyncHttpClient_V5_GET_IMAGE_ACTIVITY_STARTED = "Activity Started";
    private static final String AsyncHttpClient_V5_GET_IMAGE_ACTIVITY_ENDED = "Activity Ended";

    private static final String AsyncHttpClient_V5_GET_IMAGE_LOOP_STARTED = "Loop Started";

    //private static final String AsyncHttpClient_V5_GET_IMAGE_MEMORY_BEFORE = "Memory Before";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(AsyncHttpClient_V5_GET_IMAGE_ACTIVITY_STARTED, String.valueOf(System.currentTimeMillis()));
        setContentView(R.layout.activity_main);
        linearLayout = findViewById(R.id.linearLayout);
        getImage("1");
    }


    public void getImage(String size) {

        //start loop
        Log.d(AsyncHttpClient_V5_GET_IMAGE_LOOP_STARTED, String.valueOf(System.currentTimeMillis()));

        //garbage collector
       // System.gc();

        // Memory usage before the for loop
      //  Log.i(AsyncHttpClient_V5_GET_IMAGE_MEMORY_BEFORE, String.valueOf(System.currentTimeMillis()));

        for (int i = 1; i <= 100; i++) {

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);

            // create imageViews programatically in each iteration
            final ImageView image = new ImageView(this);

            // add layout parameters into iamge
            image.setLayoutParams(lp);
            // Adds the view to the layout
            linearLayout.addView(image);

            App.getInstance().getClient().get("https://desolate-beach-17272.herokuapp.com/downloadFile/1mb1.jpg", new FileAsyncHttpResponseHandler(this) {
                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, File file) {
                    Log.e("ERROR", throwable.toString());
                    finish();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, File file) {

                    responseCounter++;
                    Log.d("response ", String.valueOf( statusCode ));
                    BitmapFactory.Options options = new BitmapFactory.Options();
//                    options.inSampleSize = calculateInSampleSize(options, 100,100);
//                    options.inJustDecodeBounds = false;
                    options.inSampleSize = 8;
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                    image.setImageBitmap(bitmap);
                    if(bitmap!=null)
                    {

                        bitmap=null;
                        //bitmap.recycle();
                    }
                    if (responseCounter == 99) {
                        finish();
                    }
                }
            });

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       // System.gc();
        //end the app
        Log.d(AsyncHttpClient_V5_GET_IMAGE_ACTIVITY_ENDED, String.valueOf(System.currentTimeMillis()));
        android.os.Process.killProcess(android.os.Process.myPid());
    }

//    public static int calculateInSampleSize(
//            BitmapFactory.Options options, int reqWidth, int reqHeight) {
//        // Raw height and width of image
//        final int height = options.outHeight;
//        final int width = options.outWidth;
//        int inSampleSize = 1;
//
//        if (height > reqHeight || width > reqWidth) {
//
//            final int halfHeight = height / 2;
//            final int halfWidth = width / 2;
//
//            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
//            // height and width larger than the requested height and width.
//            while ((halfHeight / inSampleSize) >= reqHeight
//                    && (halfWidth / inSampleSize) >= reqWidth) {
//                inSampleSize *= 2;
//            }
//        }
//
//        return inSampleSize;
//    }

}
